#!/usr/bin/python

import websockify

websockify.websocketproxy.websockify_init()
